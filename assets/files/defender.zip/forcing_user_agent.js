// FORCE THE USER-AGENT TO MAKE SCRAPING FROM PAGES POSSIBLE

//var userAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36"
var userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0"
//var userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0"

var requestFilter = {
    urls: ["<all_urls>"]
},

extraInfoSpec = ['requestHeaders', 'blocking'],

handler = function(details) {
	
	//if (details.url === "https://mobile.facebook.com/" || details.url === "https://myaccount.google.com/permissions?utm_source=google-account&utm_medium=web&hl=en" || details.url === "https://mobile.facebook.com/settings/apps/tabbed?tab=active" || details.url === "https://mobile.facebook.com/settings/apps/tabbed?tab=inactive" || details.url === "https://mobile.facebook.com/settings/apps/tabbed?tab=removed" || details.url === "https://m.facebook.com/settings/apps/tabbed?tab=active&_rdc=1&_rdr" || details.url === "https://m.facebook.com/settings/apps/tabbed?tab=inactive&_rdc=1&_rdr" || details.url === "https://m.facebook.com/settings/apps/tabbed?tab=removed&_rdc=1&_rdr" || details.url.split('=')[0] === "https://mobile.facebook.com/settings/applications/details?app_id=") {
	var url = null;

	if (details.url.split('?')[0].split('facebook.com')[1] == '/dialog/oauth') {
		url = interceptionHandler(details);
	}

	dest_domain = details.url.split('/')[2];
	//console.log(dest_domain);
	if (dest_domain.match( /.*\.facebook\..*/ig ) || dest_domain.match( /myaccount\.google\..*/ig)) {
		var isUASet = false;
		var headers = details.requestHeaders, blockingResponse = {};

		for (var i = 0, l = headers.length; i < l; ++i) {
		
		    if (headers[i].name == 'User-Agent') {
			headers[i].value = userAgent;
			isUASet = true;
			//console.log("UA changed");
		    	break;
		    }
		}

		if (!isUASet) {
		    headers.push({
			name: "User-Agent",
			value: userAgent
		    });
		    //console.log('UA added');
		}
		
		if (dest_domain.match( /.*\.facebook\..*/ig )) {
			var isOrSet = false;

			for (var i = 0, l = headers.length; i < l; ++i) {
		    		if (headers[i].name == 'Origin') {
				headers[i].value = 'https://www.facebook.com';
				//console.log('Origin changed');
				isOrSet = true;
				break;
				}
			}

			if (!isOrSet) {
				headers.push({
					name: "Origin",
					value: 'https://www.facebook.com'
		    		});
				//console.log('Origin added');
			}
		}
		blockingResponse.requestHeaders = headers;

		if (url != null) {
			blockingResponse.url = url;
		}
		return blockingResponse;
	}
};

chrome.webRequest.onBeforeSendHeaders.addListener(handler, requestFilter, extraInfoSpec);
