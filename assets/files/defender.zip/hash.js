function encryptProm(text) {
	const encoder = new TextEncoder();
	const data = encoder.encode(text);
	return window.crypto.subtle.digest('SHA-256', data);
}

function hexString(buffer) {
  const byteArray = new Uint8Array(buffer);
  const hexCodes = [...byteArray].map(value => {
    const hexCode = value.toString(16);
    const paddedHexCode = hexCode.padStart(2, '0');
    return paddedHexCode;
  });
 return hexCodes.join('');
}
