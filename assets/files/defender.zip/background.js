// ----------------------------------------------------------------------------------------------------------------------------------- //
// TAKES CARE OF GATHERING INFORMATION FROM FACEBOOK DIALOG ON ACCEPTED PERMISSIONS AND HANDLES INITIALIZATION OF STRUCTURES IN MEMORY //
// ----------------------------------------------------------------------------------------------------------------------------------- //

browser = (chrome || browser)

var acceptedPermissions = [];
var askedPermissions = [];

var serverAddress = "https://depalma.unfiltered.seclab.cs.ucsb.edu:4443/"

var scopeConversionTable = {
	'name and profile picture':'public_profile',
	'friends list': 'user_friends',
	'hometown': 'user_hometown',
	'current city': 'user_location',
	'photos': 'user_photos',
	'email address':'email',
	'Page likes':'user_likes',
	'timeline posts': 'user_posts',
	'birthday': 'user_birthday',
	'events': 'user_events',
	'videos': 'user_videos',
	'tagged places': 'user_tagged_places',
	'gender': 'user_gender',
	'timeline link' : 'user_link',
	'age range': 'user_age_range'
}

function generatePermissionsArray(arr) {

	var tmp_array = []

	try {
		for (i in arr) {
			if (scopeConversionTable[arr[i]]) {
				tmp_array.push(scopeConversionTable[arr[i]])		
			}
			else {
				tmp_array.push('UNCAUGHT_' + arr[i]);
			}
		}
		console.log(tmp_array)
		return tmp_array
	}
	catch(err) {
		console.log('ERROR in getting permissions keywords from messages - [ '+err+' ]');
		return null;
	}
}

// sends information to db server when a website permissions are restored
function sendRestoreStatusUpdate(app_id, user_id, scopes) {
	encryptProm(user_id).then( digest => {
		file = JSON.stringify({user_id:hexString(digest), app_id:app_id, scopes:scopes, type:'R'})
		fetch(serverAddress+'mechstatusupdate', {
			method: 'POST',
			headers: new Headers({
				"Content-Type": "application/json",
			}),
				body: file,
			}).then(function(response) {
				if (!response.ok) {
					throw Error(response.statusText);
				}
				return response;
			}).then(function(response) {
				console.log("User status update for RESTORE website sent");
			}).catch(function(error) {
				console.log(error);
			});
	});
}

function cleanOriginalUrls(app_id) {
	storage.get('original_urls', function(dic) {
		try {
			if (dic && dic['original_urls']) {
				dic = JSON.parse(dic['original_urls'])
				if (dic[app_id]) {
					delete dic[app_id]
				}
				storage.set({'original_urls':JSON.stringify(dic)})
			}
			return
		}
		catch(err) {
			console.log(err)
			return
		};
	})
}

function sendWorkingToServer(app_id, user_id, scopes, comment) {
	encryptProm(user_id).then( digest => {
		file = JSON.stringify({user_id: hexString(digest), app_id:app_id, scopes:scopes, comment:comment});
		fetch(serverAddress+'mechworking', {
			method: 'POST',
			headers: new Headers({
				"Content-Type": "application/json",
			}),
				body: file,
			}).then(function(response) {
				if (!response.ok) {
					throw Error(response.statusText);
				}
				return response;
			}).then(function(response) {
				console.log("Working website sent");
				// the counter of iteration is reset (next time the website is visited the process will restart from scratch)
				iterationWebsite[app_id+'iterator'] = 0;
				// global categories is cleaned too
				globalCategories[app_id] = undefined
				
				// clean original_urls structure in storage
				cleanOriginalUrls(app_id)

			}).catch(function(error) {
				console.log(error);
			});
		
		// send status update related to the user action when a website is working
		file = JSON.stringify({user_id:hexString(digest), app_id:app_id, scopes:scopes, type:'W'})
		fetch(serverAddress+'mechstatusupdate', {
			method: 'POST',
			headers: new Headers({
				"Content-Type": "application/json",
			}),
				body: file,
			}).then(function(response) {
				if (!response.ok) {
					throw Error(response.statusText);
				}
				return response;
			}).then(function(response) {
				console.log("User status update for WORKING website sent");
			}).catch(function(error) {
				console.log(error);
			});
	});
	
	file = JSON.stringify({app_id:app_id, scopes:scopes})
	fetch(serverAddress+'updateworkingsupport', {
		method: 'POST',
		headers: new Headers({
			"Content-Type": "application/json",
		}),
			body: file,
		}).then(function(response) {
			if (!response.ok) {
				throw Error(response.statusText);
			}
			return response;
		}).then(function(response) {
			console.log("Working website2 sent");
		}).catch(function(error) {
			console.log(error);
		});
}

// send failures not related to lack of permissions
function sendFailureToServer(app_id, user_id, description) {
	encryptProm(user_id).then( digest => {
		file = JSON.stringify({user_id:hexString(digest), app_id:app_id, desc:description});
		fetch(serverAddress+'mechfailure', {
			method: 'POST',
			headers: new Headers({
				"Content-Type": "application/json",
			}),
				body: file,
			}).then(function(response) {
				if (!response.ok) {
					throw Error(response.statusText);
				}
				return response;
			}).then(function(response) {
				console.log("External failure sent");
			}).catch(function(error) {
				console.log(error);
			});
	});
}

window.onload = function() {
	
	console.log('background script on duty')

	chrome.webRequest.onBeforeRequest.addListener(interceptionHandler, {types: ['main_frame', 'sub_frame'], urls: ["*://*.facebook.com/*"]}, ["blocking"]);

	// MESSAGES FROM CONTENT SCRIPT AND POPUP LISTENER
	browser.runtime.onMessage.addListener(
		function(req) {
			// listens to messages from content script containing information about submission 
			if (req.type == 'permissions') {
				try {
					var askedPermissions = []
					var acceptedPermissions = []
					var app_id = req.app_id;
					var user_id = req.user_id;

					askedPermissions = generatePermissionsArray(req.asked)
					acceptedPermissions = generatePermissionsArray(req.accepted)
					
					if (acceptedPermissions == null || askedPermissions == null) {
						throw 'ERROR something wrong in getting scopes keywords'
					}
					getNameAndStoreResults(app_id, user_id, acceptedPermissions);
					
				}
				catch (err) {
					console.log (err)
		 			return
		    		}

		        }
		
			if (req.type == 'submission') {
				try {
					storage.get(req.user_id, function(dic) {
						if (dic && dic[req.user_id] && dic[req.user_id]) {
							dic = JSON.parse(dic[req.user_id])
							console.log(dic)
							if (dic[req.app_id]) {
								var scopes = dic[req.app_id]['scopes']
								sendWorkingToServer(req.app_id, req.user_id, scopes, req.comment)
							}
							else {
								console.log('Internal - Failed sending submission [app_id data retrival from message and memory]')
							}
						}
						else {
							console.log('Internal - Failed sending submission [user_id data retrival from message and memory]')
						}
					})
				}
				catch(err) {
					console.log(err)
				}
			} 
			
			// send external failures with description to the server (popup sends the message)
			if (req.type == 'descrip') {
				sendFailureToServer(req.app_id, req.user_id, req.desc)
			}

			// iteration counter updated every time a new dialog (with a new set of permissions) is accepted
			if (req.type == 'increaseItCounter') {
				//iterationWebsite[req.key]++
			}
	});
}
