// -----------------------------------------------------------------------------------------------------------------------------//
// 				CHECK STATUS OF LOGGED USER IN FACEBOOK AND GETS THE ID						//
// -----------------------------------------------------------------------------------------------------------------------------//

var browser = (browser || chrome)

var userIdURL = "https://mobile.facebook.com";

function scrapeId(raw) {
	//var tmp = raw.match( /\"?USER_ID\"?:\"[0-9]*\",\"?ACCOUNT_ID\"?:\"[0-9]*\"/g);
    var reg = RegExp( "name=\"target\"[\\s]+value=\".*\"" )
    var tmp = raw.match(reg)
	if (tmp === null) {
		//console.log("Couldnt find any USERID");
		var id = null;
	}
	else {
		if (tmp[0].split('"').length > 4) {
			var id = tmp[0].split('"')[3]
		}
		else {
			var id = tmp[0].split('"')[1];
		}
	}
	if (id === '0')
		return null;
	else
		return id;
}

//get the user id from the facebook homepage
function getUserId() {

	var user_id;

	var xhr_id_fb = new XMLHttpRequest();
	xhr_id_fb.open("GET", userIdURL, true);
	xhr_id_fb.send();
	xhr_id_fb.onload = function(e) {
		if (xhr_id_fb.readyState === 4) {
			if (xhr_id_fb.status === 200) {
				var user_id = scrapeId(xhr_id_fb.responseText);
				
				chrome.runtime.sendMessage({
					type:'user_id',
					user_id:user_id
				})
			}
		xhr_id_fb = null;
		}
	}
}
