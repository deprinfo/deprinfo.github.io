var urlGetGfid = 'https://mobile.facebook.com/settings/apps/tabbed?tab=active'
var urlPostRequest = 'https://m.facebook.com/privacy/touch/app/remove/confirm/?gfid='
var urlPostConfirm = 'https://m.facebook.com/privacy/touch/app/remove?'

function handleFetchErrors(response) {
	if (!response.ok) {
		console.log(response);
		throw Error(response.statusText);
	}
	return response;
}

// opens the new dialog window with updated permissions
function openOriginalDialog(app_id) {
	storage.get('original_urls', function(dic) {
		console.log(dic['original_urls'])
		if (dic) {
			dic = JSON.parse(dic['original_urls'])
			if (dic[app_id]) {
				var url = dic[app_id]['url'] + '&RESTORE';
				console.log(url)
				window.open(url)
			}
			else {
				throw 'app_id doesnt exist in the original_urls structure'
			}
		}
		else {
			throw 'original_urls structured doesnt exist'
		}
	});
}

// to remove a website we chain the following three functions 
// removeItFetch -> postRemove -> postConfirm

function postConfirm(app_ids, fbdtsg, jazoest, gfid2, reset, user_id) {

	// builds the URL based on the app_ids which removal must be confirmed
	var urlSession = urlPostConfirm+'selected_app_ids=';
	for (var id in app_ids) {
		urlSession = urlSession + encodeURIComponent(app_ids[id]) + '%2C';
	}
	urlSession = urlSession + 'gfid=' + gfid2;

	// builds the body containing session information and the ids of website that should be removed
	parameters = "fb_dtsg="+encodeURIComponent(fbdtsg)+"&jazoest="+encodeURIComponent(jazoest)+"&confirmed=Removed"
		
	fetch(urlSession, {
		method: 'POST',
		headers: {
			"Content-Type" : "application/x-www-form-urlencoded",
			"Origin" : "https://mobile.facebook.com/"
		},
		body: parameters
		})
		.then(handleFetchErrors)
		.then(function(response) {
			console.log('OK - Successfully removed');
			
			// increment iterator for next dialog
			iterationWebsite[app_ids[0]+'iterator']++

			if (reset) {
				if (globalCategories[app_ids[0]][iterationWebsite[app_ids[0]+'iterator']-1] == undefined || globalCategories[app_ids[0]][iterationWebsite[app_ids[0]+'iterator']-1] == null ) {
					globalCategories[app_ids[0]][iterationWebsite[app_ids[0]+'iterator']-1] = []
				} 
				sendRestoreStatusUpdate(app_ids[0], user_id, globalCategories[app_ids[0]][iterationWebsite[app_ids[0]+'iterator']-1])
				// after removal is complete open the new dialog
				openOriginalDialog(app_ids[0]);
			}
		}).catch(function(error) {
			console.log(error);
		});
}

function postRemove(app_ids, fbdtsg, jazoest, gfid1, reset, user_id) {

	// builds the body containing session information and the ids of website that should be removed
	parameters = "fb_dtsg="+encodeURIComponent(fbdtsg)+"&jazoest="+encodeURIComponent(jazoest)

	for (var id in app_ids) {
		parameters = parameters +'&selected_app_ids[]='+ encodeURIComponent(app_ids[id]);
	} 

	fetch(urlPostRequest+encodeURIComponent(gfid1), {
		method: 'POST',
		headers: {
			"Content-Type" : "application/x-www-form-urlencoded",
			"Origin" : "https://mobile.facebook.com/"
		},
		body: parameters
		})
		.then(handleFetchErrors)
		.then(function(response) {
			response.text().then(function(t) {
				var reg = RegExp("gfid=[a-zA-Z0-9-_]*\"", 'g');
				tmp = t.match(reg);
				if (tmp) {
					gfid2 = tmp[0].split('=')[1].split('"')[0];
				}
				else {
					console.log("no gfid2 found");
				}
				
				var reg = RegExp( "name=\"fb_dtsg\"[\\s]+value=\".*\"[\\s]+autocomplete=\"off\"[\\s]+/><input type=\"hidden\"[\\s]+name=\"jazoest\"[\\s]+value=\".*\"[\\s]+autocomplete", 'ig');
				tmp = t.match(reg);
				
				if (tmp) {
					var fbdtsg = tmp[0].split('=')[2].split('"')[1];
					var jazoest = tmp[0].split('=')[6].split('"')[1];
					postConfirm(app_ids, fbdtsg, jazoest, gfid2, reset, user_id)  
				}
				else {
					console.log("no tokens found");
				}
			})
		}).catch(function(error) {
			console.log(error);
		});
}

function removeItFetch(app_ids, reset, user_id) {
	
	fetch(urlGetGfid, {
			method: 'GET',

			headers: {
				"Origin" : "https://mobile.facebook.com/"
			}
		})
		.then(handleFetchErrors)
		.then(function(response) {
			response.text().then(function(t) {
				//var reg = RegExp("gfid=[a-zA-Z0-9-_]*\"", 'g');
				var reg = RegExp("gfid=[a-zA-Z0-9-_]*", 'g');
				tmp = t.match(reg);
				console.log(t)
                if (tmp) {
					gfid1 = tmp[0].split('=')[1].split('"')[0];
				}
				else {
					console.log("no gfid1 found");
				}

				var reg = RegExp( "name=\"fb_dtsg\"[\\s]+value=\".*\"[\\s]+autocomplete=\"off\"[\\s]+/><input type=\"hidden\"[\\s]+name=\"jazoest\"[\\s]+value=\".*\"[\\s]+autocomplete", 'ig');
				tmp = t.match(reg);
				
				if (tmp) {
					var fbdtsg = tmp[0].split('=')[2].split('"')[1];
					var jazoest = tmp[0].split('=')[6].split('"')[1];
				}
				else {
					console.log("no tokens found");
				}
				if (gfid1 && fbdtsg && jazoest) {
					// first post request
					postRemove(app_ids, fbdtsg, jazoest, gfid1, reset, user_id);
				}
			})
		}).catch(function(error) {
			console.log(error);
		});
}

