var browser = (browser || chrome) // guarantees compatibility with firefox browser
var backgroundPage // background page stored globally

var storage = chrome.storage.sync;

function buildWebsitesDropdown(user_id) {
	storage.get(user_id, function(dic) {
		try {
			if (!dic[user_id] ) {
				console.log(dic)
				throw "No structure in memory"
				return;
			}
			else {
				console.log(dic)
				dic = JSON.parse(dic[user_id])
			}
			var outputHtml = '';

			// check if a 'last loggedin website' exists
			if (backgroundPage.lastLoggedIn && dic[backgroundPage.lastLoggedIn]) {
				outputHtml = outputHtml + '<option selected value='+backgroundPage.lastLoggedIn+'>'+ dic[backgroundPage.lastLoggedIn]['name']+'</option>'	
			}
			else {
				// if there is no 'last loggedin website' a random tagline is written
				outputHtml = outputHtml + '<option id="chooseWebsite" selected value="noWebsite">Choose a website</option>'
			}	

			for (var key in dic) {
			// add all other values in the dropdown menu
				if (key != backgroundPage.lastLoggedIn) {
					// the last loggedin website is ignored (if existing)
					outputHtml = outputHtml + '<option value='+key+'>'+dic[key]['name']+'</option>';
				}
			}
			
			document.getElementById('inlineFormCustomSelect').innerHTML = outputHtml;
			updateIcon();
		}
		catch(err) {
			// no websites accessed !!!!!!!!!!!
			// add code to write a warning message on the popup
			var outputHtml = '<option id="noWebsite" selected value="noWebsite">No websites available</option>'
			document.getElementById('inlineFormCustomSelect').innerHTML = outputHtml;
			document.getElementById('websiteIcon').setAttribute('hidden', true)
			document.getElementById('inlineFormCustomSelect').style["width"] = '100%';
			document.getElementById('restoreButton').setAttribute('disabled', true);
			document.getElementById('workingWebsite').setAttribute('disabled', true);
			document.getElementById('failingWebsite').setAttribute('disabled', true);
			console.log(err)
		}
	});

}

// update icon based on the value in the scrolldown menu
function updateIcon() {
	try {
		var app_id = document.getElementById('inlineFormCustomSelect').value;
		storage.get('icons', function(dic) {
			var struct = JSON.parse(dic['icons']);
			url = struct[app_id]
			if (app_id == 'noWebsite') {
				document.getElementById('websiteIcon').setAttribute('hidden', true);
				document.getElementById('inlineFormCustomSelect').style["width"] = '100%';
				document.getElementById('restoreButton').setAttribute('disabled', true);
				document.getElementById('workingWebsite').setAttribute('disabled', true);
				document.getElementById('failingWebsite').setAttribute('disabled', true);
			}
			else {
				document.getElementById('websiteIcon').setAttribute('src',url)
				document.getElementById('websiteIcon').removeAttribute('hidden')
				document.getElementById('inlineFormCustomSelect').style["width"] = '78%';
				document.getElementById('restoreButton').removeAttribute('disabled');
				document.getElementById('workingWebsite').removeAttribute('disabled');
				document.getElementById('failingWebsite').removeAttribute('disabled');
			}
		})
	}
	catch(err) {
		console.log('ERROR in printing website icon - ' + err)
		document.getElementById('websiteIcon').setAttribute('hidden', true)
		document.getElementById('inlineFormCustomSelect').style["width"] = '100%';
		document.getElementById('restoreButton').setAttribute('disabled', true);
		document.getElementById('workingWebsite').setAttribute('disabled', true);
		document.getElementById('failingWebsite').setAttribute('disabled', true);
	}

}

function updateRemovalStructure(app_id, user_id) {

	var user_id_rem = user_id + 'rem';

	storage.get(user_id_rem, function(dic) {
		try {
			var dic			
			if (dic && dic[user_id_rem]) {
				dic = JSON.parse(dic[user_id_rem]);

				if (!dic[app_id]) {
					
					// get accepted permissions from the other structure
					var accepted = []
					var name
					var dic2 = {}
					storage.get(user_id, function(dic2) {
						dic2 = JSON.parse(dic2[user_id])
						name = dic2[app_id]['name']					
						accepted = dic2[app_id]['scopes']

						var struct = {'name':name, 'scopes':accepted}

						dic[app_id] = struct;
						storage.set({[user_id_rem]:JSON.stringify(dic)})
						
						removeFromStorage(app_id, user_id)
					})

				}
				else {
					//TODO: already exists (update or not?)
					throw 'Website already removed'
					removeFromStorage(app_id, user_id)
				}
			}
			else {
				var dic = {}
				var accepted = []
				var name
				storage.get(user_id, function(dic) {
					dic = JSON.parse(dic[user_id]);
					name = dic[app_id]['name']
					accepted = dic[app_id]['scopes']
				
					dic = {[app_id]:{'name':name, 'scopes': accepted}};
					storage.set({[user_id_rem]:JSON.stringify(dic)});
					removeFromStorage(app_id, user_id)

				})			
			}
		}
		catch(err) {
			console.log('ERROR in updating removal structure - ' + err);
			removeFromStorage(app_id, user_id)
		}
	})

}

function removeFromStorage(app_id, user_id) {

	// remove the entry from structure stored in sync storage
	// reset value of the last added if it's the removed one
	storage.get(user_id, function(dic) {
		try {
			var dic = JSON.parse(dic[user_id]);
			delete(dic[app_id])
		}
		catch(err) {
			console.log("ERROR removing entry from storage - ["+err+"]");
		}

	storage.set({[user_id]:JSON.stringify(dic)});
	
	if (backgroundPage.lastLoggedIn == app_id) {
		backgroundPage.lastLoggedIn = undefined;
	}

	buildWebsitesDropdown(user_id);
	});
}

// function to add a working website

// print the 'logout' interface and hide the 'restore' one
function loggedOut() {
	document.getElementById('resetWebsite').setAttribute('hidden', true);
	document.getElementById('loadingInterface').setAttribute('hidden', true);
	document.getElementById('plsLogin').removeAttribute('hidden');
}

function loaded() {
	document.getElementById('loadingInterface').setAttribute('hidden', true);
	document.getElementById('plsLogin').setAttribute('hidden', true);
	document.getElementById('resetWebsite').removeAttribute('hidden');
}

window.onload = function() {

	var app_id = []
	var user_id = 'nope';
	
	chrome.runtime.onMessage.addListener (
		function(req) {
			if (req.type == 'user_id') {
				console.log(user_id)
				user_id = req.user_id; // it can be null if getting user_id fails (probably no user logged in)
				if (user_id != null && user_id != 'nope') {
					buildWebsitesDropdown(user_id)
					loaded()
				}
				else {
					// ADD A 'please login' MESSAGE AND HIDE THE DROPDOWN MENU
					loggedOut();	
					//alert('no user_id - ' + user_id);
				}
			}
		}
	)

	browser.runtime.getBackgroundPage(function(backgroundpage) {
		backgroundPage = backgroundpage;

		backgroundPage.getUserId()
	
		$('#restoreButton').click(function() {
			
			app_id[0] = document.getElementById('inlineFormCustomSelect').value;
			
			try {
				if (user_id == 'nope' || user_id == null) {
					throw "user_id is not defined"
				}
				backgroundPage.removeItFetch(app_id, true, user_id)

				updateRemovalStructure(app_id[0], user_id)
					
				if (!backgroundPage.logoutFromWebsite()) {
					alert("LOGOUT from the website failed, please do it manually to apply changes to permissions")
				}
			}
			catch(err) {
				console.log("Failed removing permission for " + app_id[0] + " ["+err+"]")
			}
		});	

		// submit a working website to db server
		$('#submitButton').click(function() {
							
		
			try {
				if (user_id == 'nope' || user_id == null) {
					throw "user_id is not defined"
				}
				var app_id_tmp = document.getElementById('inlineFormCustomSelect').value;
				var user_id_tmp = user_id;
				var comment = $('#workingDescription').val()
				
				chrome.runtime.sendMessage({user_id: user_id_tmp, app_id:app_id_tmp, comment:comment, type:'submission'})
				
				backgroundPage.removeItFetch([app_id], false)	
				removeFromStorage(app_id_tmp, user_id);
			}
			catch(err) {
				console.log("Failed submitting permissions for " + app_id[0] + " ["+err+"]")
			}
		});

		// controls for sending failures
		$('#failureDescription').on('input', function(e){
    			$('.word-counter').text(this.value.length+'/300');
			if ($('#failureDescription').val().length != 0) {
				$('#failureButton').removeAttr('disabled')
				console.log($('#failureDescription').val().length)
			}
			else {
				console.log($('#failureDescription').val().length)
				$('#failureButton').attr('disabled', true)
			}
		})


		// controls for sending comment on working website
		$('#workingDescription').on('input', function(e){
    			$('.word-counter').text(this.value.length+'/500');
			if ($('#workingDescription').val().length != 0) {
				console.log($('#workingDescription').val().length)
			}
			else {
				console.log($('#workingDescription').val().length)
			}
		})

		$('#failureButton').on('click', function(e) {
			
			if ($('#failureDescription').val().length != 0) {
				try {
					if (user_id == 'nope' || user_id == null) {
						throw "user_id is not defined"
					}
					else {
						var app_id_tmp = document.getElementById('inlineFormCustomSelect').value;
						var description = $('#failureDescription').val();
						chrome.runtime.sendMessage({user_id:user_id, app_id:app_id_tmp, desc:description, type:'descrip'})
						backgroundPage.removeItFetch([app_id], false)	
						removeFromStorage(app_id_tmp, user_id);
					}
				}
				catch(err) {
					console.log('ERROR in submitting failure - ['+err+']')
				}
			}
			
		});

		// set up the corresponding icon and then instantiate the listener to dinamically update it
		$('#inlineFormCustomSelect').change(function(e) {
			updateIcon();	
		});
	});
}
