var defaultIcon = "https://scontent-lax3-2.xx.fbcdn.net/v/t39.2081-6/c0.0.76.76a/p75x75/851578_455087414601994_1601110696_n.png?_nc_cat\3d%201&_nc_oc=AQmh4cA3brqVlSlbRVPMICt5qTpRWrcHo8_zuNujVQlb4SFeanzfyFsDxgrOdyKbKpQ&_nc_ht=scontent-lax3-2.xx&oh=b10641966b1033bb34c875bd70ec3916&oe=5D39BF57"

var s = document.createElement('script');
s.src = "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js";
(document.head||document.documentElement).appendChild(s);

browser = (chrome || browser)

var storage = browser.storage.sync;

console.log('vita brute');

function escapeRegExp(string){
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function scrapeId(raw) {
	var tmp = raw.match( /\"USER_ID\":\"[0-9]*\",\"ACCOUNT_ID\":\"[0-9]*\"/g);
	if (tmp === null) {
		var id = null;
	}
	else {
		var id = tmp[0].split('"')[3];
	}
	
	if (id === '0')
		return null;
	else
		return id;
}

function submissionFunction() {
	try {
		var nodes = document.getElementsByTagName('script')
		var scriptContent = nodes[nodes.length-1].textContent;
		var reg = new RegExp("\"name\":\"[a-zA-Z0-9-_]*\",\"phrase\":\"[a-zA-Z0-9-_ ]*\"",'ig');

		// 1 - save in 'dic' the hashed value with the corresponding permission (key-value)
		var tmp = scriptContent.match(reg)

		if (tmp === null) {
			throw "No words in script tag available"
		}

		var dic = {};
		for (i in tmp) {
			dic[tmp[i].split('"')[3]] = tmp[i].split('"')[7];
		}

		// 2 - saves hashed value of accepted permissions 
		tmp = document.getElementsByName('read')[0].value.split(',');
		console.log(tmp)

		if (tmp === null) {
			throw "No sent hashed values found";
		}
		
		// 3 - extract the name corresponding to the sent hashed values
		var acceptedPermissions = []
		for (i in tmp) {
			if (dic[tmp[i]]) {
				console.log(dic[tmp[i]])
				acceptedPermissions.push(dic[tmp[i]]);
			}
		}	
		// public_profile is always the last (bring back in first position) ???
		console.log(acceptedPermissions)
		if (acceptedPermissions[acceptedPermissions.length-1].includes('profile')) {
			acceptedPermissions.pop()
			tmp = ['name and profile picture']
			acceptedPermissions.push.apply(tmp, acceptedPermissions)
			acceptedPermissions = tmp
		}
		
		// 4 - get all asked permissions
		var askedPermissions = [];	

		for (i in dic){
			askedPermissions.push(dic[i])	
		}

		//5 - get app_id
		var appId = document.getElementsByName('app_id')[0].value;

		//6 - get user_id
		var userId = scrapeId(document.getElementsByTagName('html')[0].innerHTML);
		browser.runtime.sendMessage({asked:askedPermissions, accepted:acceptedPermissions, app_id:appId, user_id:userId, type:'permissions'});
		browser.runtime.sendMessage({key:appId+'iterator', type:'increaseItCounter'});
	}
	catch(err) {
		alert('ERROR during execution of the extension content script please logout and repeat the process');
		console.log('ERROR during execution of the extension content script - [' + err + ']');
	}
}

window.onload = function() {
	
	var checkLoaded = setInterval(function() {
		if (document.getElementsByName('app_id')[0]) {
			console.log('loaded hopefully');
			try {

				//document.getElementById('platformDialogForm').onsubmit =  submissionFunction();	
				// submission buttons are intercepted only if dialog is crafted by the extension
				if (window.location.href.match(/www.facebook.com\/.*dialog\/oauth\?/)) {
					
					try {
						if (document.body.getElementsByTagName('img')[1].id) {
							if (document.body.getElementsByTagName('img')[1].id.includes("profile")) {
								throw 'Image refers to the profile picture'
							}
						}
						var imgUrl = document.body.getElementsByTagName('img')[1].src;
					}
					catch {
						var imgUrl = defaultIcon;
					}
			
					var app_id = document.getElementsByName('app_id')[0].value;
					storage.get('icons', function(dic) {
						try {
							if (dic && dic['icons']) {
								var struct = JSON.parse(dic['icons'])
								if (!struct[app_id]) {
									struct[app_id] = imgUrl;
									storage.set({'icons': JSON.stringify(struct)})
								}
								else {
									throw "Icon already existing"
								}
							}
							else {
								var struct = {}
								struct = {[app_id]:imgUrl}
								storage.set({'icons':JSON.stringify(struct)});
							}
						}
						catch(err) {
							console.log(err);
						}
					});

					
					if (window.location.href.substr(-8) == 'ORIGINAL') {

						var frm = $('#platformDialogForm');

						frm.submit(function (e) {
							e.preventDefault();

							$.ajax({
							    type: frm.attr('method'),
							    url: frm.attr('action'),
							    data: frm.serialize(),
							    success: function (data) {
								submissionFunction();
								if (window.location.href.substr(-16) == 'RESTORE&ORIGINAL') {
									window.close()
								}
								else {
									window.location.href += "#last";
									window.location.reload();
								}
							    },
							    error: function (data) {
								alert('An error occurred, please logout and signup again');
							    },
							});
						});
						
						//}
						if (document.getElementsByName('__CANCEL__') != undefined) {
							document.getElementsByName('__CANCEL__')[0].style.display = 'none';
							document.getElementsByName('__CANCEL__')[0].onclick = function () {
								window.close();
							}
						}
						else {
							document.getElementsByName('__SKIP__')[0].style.display = 'none';
							document.getElementsByName('__SKIP__')[0].onclick = function () {
								window.close();
							}
							
						}
					}
				}
			}
			catch(err2) {
				alert(err2)
				console.log('ERROR intercepting form submission - [' + err2 +']');
			}

			clearInterval(checkLoaded);

		}
	}, 100);
};	
