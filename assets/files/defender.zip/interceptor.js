// ----------------------------------------------------------------------------------------------------------------------------------- //
//			HANDLES INTERCEPTION OF FACEBOOK LOGIN DIALOG PAGES AND MODIFY THEM ACCORDING TO SETTINGS 		       //
// ----------------------------------------------------------------------------------------------------------------------------------- //
// !!!   DYNAMIC VERSION    !!! //
// !!! MECHANICAL TURK ONLY !!! //

var graphUrl = 'https://graph.facebook.com/';
var facebookDetailUrl = 'https://m.facebook.com/settings/applications/details/?app_id='
var iterationWebsite = {};
var lastLoggedIn = undefined;
var localStoredScopes;
var globalCategories = {}
var storage = chrome.storage.sync;

var total_scopes = ['ads_management','ads_read','groups_access_member_info','instagram_basic','instagram_manage_comments','instagram_manage_insights','read_audience_network_insights','business_management','pages_messaging','pages_messaging_subscriptions','publish_to_groups','user_tagged_places','user_videos','read_page_mailboxes','user_link','user_age_range','user_events','user_posts','read_insights','publish_pages','manage_pages','user_hometown','pages_show_list','user_gender','user_likes','user_photos','user_location','user_friends','user_birthday','email']

var groups = []
groups[0] = ['public_profile']
groups[1] = ['email']
groups[2] = ['user_birthday', 'user_gender', 'user_hometown']
groups[3] = ['user_age_range', 'user_location']
groups[4] = ['user_photos', 'user_posts', 'user_videos', 'user_tagged_places']
groups[5] = ['user_friends', 'user_likes', 'user_events', 'user_link', 'publish_to_groups', 'groups_access_member_info']
groups[6] = ['pages_show_list', 'manage_pages', 'publish_pages', 'pages_messaging_subscriptions', 'pages_messaging', 'read_page_mailboxes']
groups[7] = ['read_insights', 'business_management', 'read_audience_network_insights', 'ads_read', 'ads_management']
groups[8] = ['instagram_manage_insights', 'instagram_manage_comments', 'instagram_basic']


var permissionsRequested = [];

var lastDomainCookies = undefined;

function populateCategoriesUrl(url) {

	// get scopes and store them in memory
	var used_groups = []
	console.log(url)
	var scopes = url.split("scope=")[1].split("&")[0].replace(/%25/g, '%')
	scopes = scopes.replace(/%5F/g, '_')
	scopes = scopes.replace(/%.{2}/g, ' ')
	scopes = scopes.replace(/^\s+/g, '')
	scopes = scopes.replace(/\s+$/g, '')
	scopes = scopes.replace(/\s+/g, ' ')
	scopes = scopes.split(' ')
	var app_id = getAppId(url)
	
	//it may happens scopes in urls are separated by comma
	if (scopes.length == 1 && scopes[0].split(',').length != 1) {
		scopes = scopes[0].split(',')
	}
	//it may happens scopes in urls are separated by '+'
	else if (scopes.length == 1 && scopes[0].split('+').length != 1) {
		scopes = scopes[0].split('+')
	}
	
	// scopes are cleaned by unnecessary special characters
	for (i in scopes) {
		scopes[i] = scopes[i].replace(/[^a-z_]/g, '')
		scopes[i] = scopes[i].replace(/^_+/g, '')
		scopes[i] = scopes[i].replace(/_+$/g, '')
	}

	console.log(scopes)
	storage.set({[app_id]:scopes})

	// find non empty groups
	var existing = []
	
	for (i in groups) {
		existing[i] = groups[i].filter(el => scopes.includes(el))
	}
	// force public_profile at index 0
	if (existing[0].length == 0) {
		existing[0] = ["public_profile"]
	}

	existing = existing.filter(el => el.length != 0)
	
	// incremental approach
	var categories = incrementalGenerator(existing);

	return categories
}

function incrementalGenerator(arr) {
	var res = [];
	res[0] = ['public_profile']
	for (var i=0; i < arr.length-1; i++){
		res.push(res[i].concat(arr[i+1]))
	}
	return res
}

function scopesGenerator(originalScopes, it, categories) {
	// generates array with scopes that are requested by the website and according to the iteration
	
	//some websites encode the underscore in '%5F' 
	console.log(originalScopes)
	originalScopes = originalScopes.replace(/%5F/g, '_')
	console.log(originalScopes)
	var tmp = total_scopes.filter(el => categories[it].indexOf(el) === -1)
	console.log(tmp)
	var filteredScopes = originalScopes;

	for (i in tmp) {
		filteredScopes = filteredScopes.replace(tmp[i]+'%2C','').replace(tmp[i],'')
	}
	
	console.log(filteredScopes)
	return filteredScopes;
}

function getScopes(scopesOriginal, iteration, categories, app_id) {
// return the portion of url related to the scopes
	console.log(scopesOriginal)
	console.log(iteration)
	console.log(categories)
	console.log(app_id)
	try {
		//console.log(iteration + ' ' + categories.length)
		if (iteration >= categories.length) {
			// if iterator is bigger than categories dimension it means that all possibilities have been tried
			alert("All permissions have already been granted, if the website is not working please report a failure in the extension popup")
			return 'scope='+scopesGenerator(scopesOriginal, categories.length-1, categories)+'&'
			//throw 'Iterator out of range'
		}
		return 'scope='+scopesGenerator(scopesOriginal, iteration, categories)+'&'		
	}
	catch(err) {
		// in case of error no permission asked is modified
		console.log("ERROR in getting scopes - ["+err+"]")
		return 'scope='+scopesOriginal+'&'	
	}
}

function sendWebsiteInformation(app_id, name) {
// send information about website (name and original scopes)
	storage.get(app_id, function(dic) {
		if (dic && dic[app_id]) {
			var file = JSON.stringify({[app_id]:{name:name, scopes:dic[app_id]}});
			fetch(serverAddress+'genericwebsiteadd', {
				method: 'POST',
				headers: new Headers({
					"Content-Type": "application/json",
				}),
					body: file,
				}).then(function(response) {
					if (!response.ok) {
						throw Error(response.statusText);
					}
					return response;
				}).then(function(response) {
					console.log("General website information sent");
				}).catch(function(error) {
					console.log(error);
				});
		}
		else {
			console.log('ERROR getting website info from memory to send to the server')
		}
	});
}

function getAppId(url) {
// extract app_id out of the dialog url
	console.log(url)
	//try {
	//	var app_id = url.split('app_id=')[1].split('&')[0];
	//}
	//catch {
	//	try {
	//		var app_id = url.split('client_id=')[1].split('&')[0];
	//	}
	//	catch(err) {
	//		console.log(err);
	//		return undefined
	//	}
	//}

	var app_id = url.split('app_id=')[1]
	console.log(app_id)
	if (app_id == undefined) {
		app_id = url.split('client_id=')[1]
		console.log(app_id)
	}

	try {
		if (app_id == undefined) {
			throw "ERROR - no app_id encoded in the URL"
		}
	}
	catch(err){
		console.log(err)
		return undefined
	}

	return app_id.split('&')[0];
}

function getNameAndStoreResults(app_id, user_id, accepted) {
	//fetch the name using graphAPI starting from the app_id
	fetch(graphUrl+app_id, {
		method: "GET",
		headers : {
			"Content-Type": "application/json"
		}
	}).then( res => {
		if (res.status == 200) {
			return res.json();
		}
		else {
			// if it fails, repeat operation getting name from 'tabbed' facebook page
			fetch(facebookDetailUrl+app_id, {
				method: "GET",
				headers : {
					"Content-Type": "text/html"
				}
			}).then( res => {
				if (res.status == 200) {
					return res.text();
				}
				else {
					throw "Error retrieving name by app_id ---"
				}
			}).then ( res => { var name = res.split('<title>')[1].split('</title>')[0]; 

				// send information to server
				sendWebsiteInformation(app_id, name) 

				// save all information in a JSON file in local storage
				storage.get(user_id, function(dic) {
					try {	
						lastLoggedIn = app_id;
						var struct = {'name':name, 'scopes': accepted}
						console.log(dic)
						if (dic && dic[user_id]) {
							dic = JSON.parse(dic[user_id]);
							if (!dic[app_id]) {
								dic[app_id] = struct;
								storage.set({[user_id]:JSON.stringify(dic)})
								console.log('sett')
							}
							else {
								throw "Website already existing"
							}
						}
						else {
							var dic = {}
							dic = {[app_id]:{'name':name, 'scopes': accepted}};
							console.log(dic)
							storage.set({[user_id]:JSON.stringify(dic)});
						}
					}
					catch(err) {
						console.log(err);
						return
					};
				});
			}).catch( err => { 
				console.log(err);
				return
			});
				
		}
	}).then ( res => { 
		
		if (res	== undefined) {
			return		
		}
		var name = res['name']; 

		// send information to server
		sendWebsiteInformation(app_id, name) 

		// save all information in a JSON file in local storage
		storage.get(user_id, function(dic) {
			try {	
				lastLoggedIn = app_id;
				var struct = {'name':name, 'scopes': accepted}
				console.log(dic)
				if (dic && dic[user_id]) {
					dic = JSON.parse(dic[user_id]);
					if (!dic[app_id]) {
						dic[app_id] = struct;
						storage.set({[user_id]:JSON.stringify(dic)})
					}
					else {
						throw "Website already existing"
					}
				}
				else {
					var dic = {}
					dic = {[app_id]:{'name':name, 'scopes': accepted}};
					console.log(dic)
					storage.set({[user_id]:JSON.stringify(dic)});
				}
			}
			catch(err) {
				console.log(err);
				return
			};
		});
	}).catch( err => { 
		console.log(err);
		return
	});
}

function closeTabs() {
	// close tabs related to the website whose permissions were restored
}

function refreshTab(url) {
	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
    		for (i in tabs) {
			if (tabs[i].url.includes(url)) {
				console.log(tabs[i].url.split('/')[2])
				chrome.tabs.update(tabs[i].id, {url: 'http://' + tabs[i].url.split('/')[2]})
			}
		}
	});
}

function logoutFromWebsite() {
	//deletes cookies related to the domain in global variable lastDomainCookies
	try {
		var url = lastDomainCookies
		if (url == undefined) {
			throw 'Error - no last domain cookies'
		}

		url = url.split('/')[2]
		
		if (url.slice(0, 4) == 'www.') {
			url = url.slice(4)
		}
		
		chrome.cookies.getAll({domain: "."+url}, function(cookies) {
			console.log('cookies number: ' + cookies.length)
			
			for (i in cookies) {
				chrome.cookies.remove({url: "https://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name})
				chrome.cookies.remove({url: "http://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name})
			}

			chrome.cookies.getAll({domain: "."+url}, function(cookies) {
				console.log('cookies number after removal: ' + cookies.length)
			});
		});


		console.log('logout function ' + lastDomainCookies)

		lastDomainCookies = undefined
		refreshTab(url)

		return true
	}
	catch(err) {
		console.log(err)
		lastDomainCookies = undefined
		return false
	}
}

// ajax method async: false
// get iterator number from memory
function interceptionHandler(res) {
	try {
		if (res.url.substr(-8) == 'ORIGINAL' || res.url.substr(-5) == '#last') {
			throw 'shouldnt be intercepted'
		}
		
		if (res.method == 'GET') {
			var retUrl = undefined
			if (res.url) {

				if (res.initiator != undefined) {
					lastDomainCookies = res.initiator;
				}
				
				console.log('interceptor ' + lastDomainCookies)

				u = res.url;
				var pieces = res.url.split('scope=')
				if (pieces[0] == u) {
					console.log('no private information asked')
					return
				}
				var app_id = getAppId(res.url)
				
				var ret;
				
				console.log('global '+globalCategories[app_id])
				if (globalCategories[app_id]) {
					console.log('shouldnt be printed')
					if (iterationWebsite[app_id+'iterator']) {
						var key = app_id+'iterator'
						var current_iteration = iterationWebsite[key]
						retUrl = interceptionHandlerInternal(res, current_iteration, globalCategories[app_id])
						ret = {redirectUrl: retUrl + 'ORIGINAL'}
					}
					else {
						var key = app_id+'iterator'
						iterationWebsite[key] = 0
						retUrl = interceptionHandlerInternal(res, 0, globalCategories[app_id])
						ret = {redirectUrl: retUrl + 'ORIGINAL'}
					}
				}
				else {		
					var a = jQuery.ajax({
						url: serverAddress+'updateworkingsupport?id='+app_id,
						success: function(res2) {
							var tmp = JSON.parse(res2)
							console.log(res2)
							if (tmp.length == 0) {
								var categories = populateCategoriesUrl(res.url)
								globalCategories[app_id] = categories
								console.log(globalCategories)

								if (iterationWebsite[app_id+'iterator']) {
									var key = app_id+'iterator'
									var current_iteration = iterationWebsite[key]
									retUrl = interceptionHandlerInternal(res, current_iteration, categories)
									ret = {redirectUrl: retUrl + 'ORIGINAL'};
								}
								else {
									console.log('iterator doesnt exist for ' + app_id)
									var key = app_id+'iterator'
									// set 1 for next iteration and store but pass 0 to the handler 
									iterationWebsite[app_id+'iterator'] = 0
									retUrl = interceptionHandlerInternal(res, 0, categories)
									ret = {redirectUrl: retUrl + 'ORIGINAL'};
								}
							
							}
							else {
								var categories = tmp
								globalCategories[app_id] = categories
								console.log(categories)	
								if (iterationWebsite[app_id+'iterator']) {
									var key = app_id+'iterator'
									var current_iteration = iterationWebsite[key]
									retUrl = interceptionHandlerInternal(res, current_iteration, categories)
									ret = {redirectUrl: retUrl + 'ORIGINAL'}
								}
								else {
									var key = app_id+'iterator'
									iterationWebsite[key] = 0
									retUrl = interceptionHandlerInternal(res, 0, categories)
									ret = {redirectUrl: retUrl + 'ORIGINAL'}
								}
							}
						},
						async: false
					});
				}
				return ret;
			}
		}
	}
	catch(err) {
		console.log('Error in interception handler wrapper - ' + err)
		return
	}
}

function interceptionHandlerInternal(res, it, categories) {
	try {
		u = res.url;
		var pieces = res.url.split('scope=')
		if (pieces[0] == u) {
			return
		}
		else {
			var oldUrl = res.url;
			var app_id = getAppId(res.url)
			
			// a separate structure contains the app_id and the original url
			storage.get('original_urls', function(dic) {
				try {	
					lastLoggedIn = app_id;
					var struct = {'url':oldUrl}
					if (dic && dic['original_urls']) {
						dic = JSON.parse(dic['original_urls']);
						if (!dic[app_id]) {									
							dic[app_id] = struct;
							storage.set({'original_urls':JSON.stringify(dic)})
						}
						else {
							throw "app-id already existing"
						}
					}
					else {
						var dic = {}
						dic = {[app_id]:{'url':oldUrl}};
						storage.set({'original_urls':JSON.stringify(dic)});
					}
				}
				catch(err) {
					console.log(err);
					return
				};
			});
			
			if (!app_id) {
				throw "Generic error in getting signup info"
			}
		}
		var second_part=''
		for (i in pieces[1].split('&')) {
			if (i != 0) {
				second_part = second_part + pieces[1].split('&')[i]
				second_part = second_part + '&'
			}
		}
		console.log(second_part)
		return pieces[0]+ getScopes(pieces[1].split('&')[0], it, categories, app_id) + second_part;
	}
	catch(err) {
		console.log(err);
		return
	}
}
