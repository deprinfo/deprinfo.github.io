var defaultIcon = "https://scontent-lax3-2.xx.fbcdn.net/v/t39.2081-6/c0.0.76.76a/p75x75/851578_455087414601994_1601110696_n.png?_nc_cat=1&_nc_ht=scontent-lax3-2.xx&oh=6974350e8d2ec04336715afe33dddc49&oe=5C9B8B57&"

var s = document.createElement('script');
s.src = "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js";
(document.head||document.documentElement).appendChild(s);

browser = (chrome || browser)

var storage = browser.storage.sync;

console.log("vita brute")

function escapeRegExp(string){
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function scrapeId(raw) {
	var tmp = raw.match( /\"USER_ID\":\"[0-9]*\",\"ACCOUNT_ID\":\"[0-9]*\"/g);
	if (tmp === null) {
		//console.log("Couldnt find any USERID");
		var id = null;
	}
	else {
		var id = tmp[0].split('"')[3];
	}
if (id === '0')
	return null;
else
	return id;
}

function submissionFunction(f) {

	try {
		var nodes = document.getElementsByTagName('script')
		var scriptContent = nodes[nodes.length-1].textContent;
		var reg = new RegExp("\"name\":\"[a-zA-Z0-9-_]*\",\"phrase\":\"[a-zA-Z0-9-_ ]*\"",'ig');

		// 1 - save in 'dic' the hashed value with the corresponding permission (key-value)
		var tmp = scriptContent.match(reg)

		if (tmp === null) {
			throw "No words in script tag available"
		}

		var dic = {};
		for (i in tmp) {
			dic[tmp[i].split('"')[3]] = tmp[i].split('"')[7];
		}

		// 2 - saves hashed value of accepted permissions 
		//reg = new RegExp("<input type=\"hidden\" autocomplete=\"off\" name=\"read\" value=\"[A-Za-z0-9-_,]*\"",'ig');
		//tmp = scriptContent.match(reg);

		tmp = document.getElementsByName('read')[0].value.split(',');
		console.log(tmp)

		if (tmp === null) {
			throw "No sent hashed values found";
		}
		
		// 3 - extract the name corresponding to the sent hashed values
		var acceptedPermissions = []
		for (i in tmp) {
			if (dic[tmp[i]]) {
				acceptedPermissions.push(dic[tmp[i]]);
			}
		}	

		//browser.runtime.sendMessage({msg:acceptedPermissions, type:'accepted'});
		
		// 4 - get all asked permissions
		var askedPermissions = [];	

		for (i in dic){
			askedPermissions.push(dic[i])	
		}

		//5 - get app_id
		var appId = document.getElementsByName('app_id')[0].value;
		console.log(appId)

		//6 - get user_id
		var userId = scrapeId(document.getElementsByTagName('html')[0].innerHTML);
		
		console.log(userId);

		browser.runtime.sendMessage({asked:askedPermissions, accepted:acceptedPermissions, app_id:appId, user_id:userId, type:'permissions'});
		//browser.runtime.sendMessage({url:window.location.href, type:'refresh'});
		

		//document.getElementById('platformDialogForm').submit();
		
		//window.close()
		return false;
	}
	catch(err) {
		console.log('ERROR during execution of the extension content script - [' + err + ']');
	}
}

window.onload = function() {
	
	try {
		//document.getElementById('platformDialogForm').onsubmit =  submissionFunction();
		
		// submission buttons are intercepted only if dialog is crafted by the extension
		if (window.location.href.match(/www.facebook.com\/.*dialog\/oauth\?app_id/)) {
			
			try {
				var imgUrl = document.body.getElementsByTagName('img')[1].src;
			}
			catch {
				var imgUrl = defaultIcon;
			}
	
			var app_id = document.getElementsByName('app_id')[0].value;
			storage.get('icons', function(dic) {
				try {
					if (dic && dic['icons']) {
						var struct = JSON.parse(dic['icons'])
						if (!struct[app_id]) {
							struct[app_id] = imgUrl;
							storage.set({'icons': JSON.stringify(struct)})
						}
						else {
							throw "Icon already existing"
						}
					}
					else {
						var struct = {}
						struct = {[app_id]:imgUrl}
						storage.set({'icons':JSON.stringify(struct)});
					}
				}
				catch(err) {
					console.log(err);
				}
			});

			
			if (window.location.href.substr(-8) == 'ORIGINAL') {
				document.getElementById('platformDialogForm').removeAttribute('onsubmit');
				document.getElementsByName('__CONFIRM__')[0].onclick = function () {
					$('#platformDialogForm').ajaxForm(function() {
						submissionFunction();
						window.close();
					});
				}
				if (document.getElementsByName('__CANCEL__') != undefined) {
					document.getElementsByName('__CANCEL__')[0].onclick = function () {
						window.close();
					}
				}
				else {
					document.getElementsByName('__SKIP__')[0].onclick = function () {
						window.close();
					}
					
				}
			}
		}
	}
	catch(err2) {
		console.log('ERROR intercepting form submission - [' + err2 +']');
	}
};	
